#!/bin/bash

APP_NAME="UtilitaryApp"

INSTALL_DIR="$HOME/.local/share/$APP_NAME"
BIN_DIR="$HOME/.local/bin"
DESKTOP_DIR="$HOME/.local/share/applications"

mkdir -p "$INSTALL_DIR"
mkdir -p "$BIN_DIR"
mkdir -p "$DESKTOP_DIR"

echo "Installation de $APP_NAME..."

# Copie l'application
cp UtilitaryApp.sh "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/UtilitaryApp.sh"

# Lanceur
cat > "$BIN_DIR/$APP_NAME" <<EOF
#!/bin/bash
exec "$INSTALL_DIR/UtilitaryApp.sh"
EOF

chmod +x "$BIN_DIR/$APP_NAME"

# Icône
if [ -f icon.png ]; then
    cp icon.png "$INSTALL_DIR/icon.png"
    ICON="$INSTALL_DIR/icon.png"
else
    ICON="applications-system"
fi

# Fichier desktop
cat > "$DESKTOP_DIR/$APP_NAME.desktop" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=UtilitaryApp
Comment=UtilitaryApp
Exec=$BIN_DIR/$APP_NAME
Icon=$ICON
Terminal=false
Categories=Utility;
StartupNotify=true
EOF

chmod +x "$DESKTOP_DIR/$APP_NAME.desktop"

# Copie sur le bureau
if [ -d "$HOME/Desktop" ]; then
    cp "$DESKTOP_DIR/$APP_NAME.desktop" "$HOME/Desktop/"
    chmod +x "$HOME/Desktop/$APP_NAME.desktop"
fi

if [ -d "$HOME/Bureau" ]; then
    cp "$DESKTOP_DIR/$APP_NAME.desktop" "$HOME/Bureau/"
    chmod +x "$HOME/Bureau/$APP_NAME.desktop"
fi

echo
echo "Installation terminée !"
echo "Tu peux lancer UtilitaryApp depuis le menu Applications."
