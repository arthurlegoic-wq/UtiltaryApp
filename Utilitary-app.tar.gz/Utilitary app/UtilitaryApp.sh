#!/bin/bash

APP_NAME="UtilitaryApp"
SCRIPT_PATH="$(readlink -f "$0")"
ICON="applications-system"

DESKTOP_FILE="$HOME/.local/share/applications/${APP_NAME}.desktop"

# Création du fichier .desktop
if [ ! -f "$DESKTOP_FILE" ]; then
    mkdir -p "$HOME/.local/share/applications"

    cat > "$DESKTOP_FILE" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=$APP_NAME
Comment=UtilitaryApp
Exec=$SCRIPT_PATH
Icon=$ICON
Terminal=false
Categories=Utility;
StartupNotify=true
EOF

    chmod +x "$DESKTOP_FILE"

    # Copie sur le bureau si présent
    if [ -d "$HOME/Desktop" ]; then
        cp "$DESKTOP_FILE" "$HOME/Desktop/"
        chmod +x "$HOME/Desktop/${APP_NAME}.desktop"
    elif [ -d "$HOME/Bureau" ]; then
        cp "$DESKTOP_FILE" "$HOME/Bureau/"
        chmod +x "$HOME/Bureau/${APP_NAME}.desktop"
    fi
fi

# Vérifie Zenity
if ! command -v zenity >/dev/null 2>&1; then
    zenity --error \
        --title="Erreur" \
        --text="Zenity n'est pas installé.\n\nInstallez-le avec :\nsudo apt install zenity"
    exit 1
fi

# Lancement de l'application
while true; do
    CHOICE=$(zenity --list \
        --title="UtilitaryApp" \
        --width=420 \
        --height=300 \
        --text="Bienvenue dans UtilitaryApp" \
        --column="Menu" \
        "📅 Afficher la date" \
        "💻 Informations système" \
        "🖥 Ouvrir un terminal" \
        "❌ Quitter")

    case "$CHOICE" in
        "📅 Afficher la date")
            zenity --info --title="Date" --text="$(date)"
            ;;
        "💻 Informations système")
            zenity --info \
                --width=500 \
                --text="Utilisateur : $USER

Machine : $(hostname)

Noyau : $(uname -r)"
            ;;
        "🖥 Ouvrir un terminal")
            (x-terminal-emulator || gnome-terminal || konsole || xfce4-terminal || xterm) >/dev/null 2>&1 &
            ;;
        ""|"❌ Quitter")
            exit 0
            ;;
    esac
done
